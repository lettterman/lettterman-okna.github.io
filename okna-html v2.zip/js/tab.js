$(document).ready(function () {
    $('#to_remont_ajax_1').click(function (event) {
            $('#remont_ajax_1').css('display', 'block');
            $('#to_remont_ajax_1').css('background-color', '#02A6E1');
            $('#to_remont_ajax_1').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'none');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_2').click(function (event) {
            $('#remont_ajax_2').css('display', 'block');
            $('#to_remont_ajax_2').css('background', '#02A6E1');
            $('#to_remont_ajax_2').css('color', '#fff');

            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'none');
                $('#remont_ajax_2_line').css('display', 'none');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_3').click(function (event) {
            $('#remont_ajax_3').css('display', 'block');
            $('#to_remont_ajax_3').css('background', '#02A6E1');
            $('#to_remont_ajax_3').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'none');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_4').click(function (event) {
            $('#remont_ajax_4').css('display', 'block');
            $('#to_remont_ajax_4').css('background', '#02A6E1');
            $('#to_remont_ajax_4').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'none');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_5').click(function (event) {
            $('#remont_ajax_5').css('display', 'block');
            $('#to_remont_ajax_5').css('background', '#02A6E1');
            $('#to_remont_ajax_5').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'none');
                $('#remont_ajax_4_line').css('display', 'none');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_6').click(function (event) {
            $('#remont_ajax_6').css('display', 'block');
            $('#to_remont_ajax_6').css('background', '#02A6E1');
            $('#to_remont_ajax_6').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'none');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_7').click(function (event) {
            $('#remont_ajax_7').css('display', 'block');
            $('#to_remont_ajax_7').css('background', '#02A6E1');
            $('#to_remont_ajax_7').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'none');
                $('#remont_ajax_6_line').css('display', 'block');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_8').click(function (event) {
            $('#remont_ajax_8').css('display', 'block');
            $('#to_remont_ajax_8').css('background', '#02A6E1');
            $('#to_remont_ajax_8').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');
            $('#remont_ajax_9').css('display', 'none');
            $('#to_remont_ajax_9').css('background-color', '#fff');
            $('#to_remont_ajax_9').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'none');
                $('#remont_ajax_6_line').css('display', 'none');
        }
    );
});
$(document).ready(function () {
    $('#to_remont_ajax_9').click(function (event) {
            $('#remont_ajax_9').css('display', 'block');
            $('#to_remont_ajax_9').css('background', '#02A6E1');
            $('#to_remont_ajax_9').css('color', '#fff');

            $('#remont_ajax_2').css('display', 'none');
            $('#to_remont_ajax_2').css('background-color', '#fff');
            $('#to_remont_ajax_2').css('color', '#7D7D7D');
            $('#remont_ajax_3').css('display', 'none');
            $('#to_remont_ajax_3').css('background-color', '#fff');
            $('#to_remont_ajax_3').css('color', '#7D7D7D');
            $('#remont_ajax_4').css('display', 'none');
            $('#to_remont_ajax_4').css('background-color', '#fff');
            $('#to_remont_ajax_4').css('color', '#7D7D7D');
            $('#remont_ajax_5').css('display', 'none');
            $('#to_remont_ajax_5').css('background-color', '#fff');
            $('#to_remont_ajax_5').css('color', '#7D7D7D');
            $('#remont_ajax_6').css('display', 'none');
            $('#to_remont_ajax_6').css('background-color', '#fff');
            $('#to_remont_ajax_6').css('color', '#7D7D7D');
            $('#remont_ajax_7').css('display', 'none');
            $('#to_remont_ajax_7').css('background-color', '#fff');
            $('#to_remont_ajax_7').css('color', '#7D7D7D');
            $('#remont_ajax_8').css('display', 'none');
            $('#to_remont_ajax_8').css('background-color', '#fff');
            $('#to_remont_ajax_8').css('color', '#7D7D7D');
            $('#remont_ajax_1').css('display', 'none');
            $('#to_remont_ajax_1').css('background-color', '#fff');
            $('#to_remont_ajax_1').css('color', '#7D7D7D');

                $('#remont_ajax_1_line').css('display', 'block');
                $('#remont_ajax_2_line').css('display', 'block');
                $('#remont_ajax_3_line').css('display', 'block');
                $('#remont_ajax_4_line').css('display', 'block');
                $('#remont_ajax_5_line').css('display', 'block');
                $('#remont_ajax_6_line').css('display', 'none');
        }
    );
});